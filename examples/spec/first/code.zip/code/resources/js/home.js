(function() {
	$('#exampleInputTime').datetimepicker({
		format: 'yyyy-mm-dd hh:ii',
		autoclose: true,
		todayHighlight: true,
		language: 'zh-CN'
	});
})()